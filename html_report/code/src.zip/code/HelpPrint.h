﻿#pragma once

class HelpPrint {
public:
	static void print();
	static bool handleKeys(const unsigned char key, const int x, const int y);
	
};
